
#ifndef Mars_verinfo_h
#define Mars_verinfo_h

#define MARS_REVISION "cf309619"
#define MARS_PATH "btlogger/xlogger-xcframework"
#define MARS_URL ""
#define MARS_BUILD_TIME "2026-08-18 14:15:02"
#define MARS_TAG ""
#define MARS_BUILD_TIMESTAMP 1787033702

#endif
